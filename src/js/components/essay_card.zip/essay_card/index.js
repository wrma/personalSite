/*
* @Author: ThinkPad
* @Date:   2017-10-25 14:11:55
* @Last Modified by:   wrma
* @Last Modified time: 2017-12-04 20:38:00
*/
var React = require('react');
var ReactDOM = require('react-dom');
import essayCardCss from './index.css';
import {Card,Icon} from 'antd';

export default class EssayCard extends React.Component{
    constructor(){
        super();
        this.state={
            essay:''
        };
    };
    componentWillMount(){
        var myFetchOptions = {
            method : 'GET'
        };
        fetch("https://www.easy-mock.com/mock/59c76db1e0dc663341b7173c/index/articles", myFetchOptions)
            .then(response => response.json())
            .then(json => {
                    this.setState({
                        essay: json
                    });
                }            
                );
        
        console.log('componentWillMount')
    };
    componentDidMount(){      
        console.log('componentDidMount');
    };
    render(){
        const essay = this.state.essay.data;
        // const {essayList} = this.state.essay.data;
        console.log(essay);
        // console.log(essay instanceof Array);
        // console.log(essay.length);
        // const essayList = essay.length
        //                 ?essay.map((item,index)=> {
        //                     <Card className={essayCardCss.card} title={item.title} extra={<a href="#">More</a>}>
        //                         <div className={essayCardCss.content}>
        //                             如果你无法简洁的表达你的想法，那只说明你还不够了解它。
        //                             -- 阿尔伯特·爱因斯坦
        //                         </div>
        //                         <div className={essayCardCss.info}>
        //                             <span>Athor：wrma</span>
        //                             <span>Date：20170923</span>
        //                             <span>阅读量（233）</span>
        //                             <span><Icon type="heart" style={{ fontSize: 12, color: '#666' }} /> 点赞（12）</span>
        //                         </div>
        //                     </Card>
        //                 })
        //                 :'没有加载到任何文章';
        return(
            <div>
                
            </div>
        );
    }
}